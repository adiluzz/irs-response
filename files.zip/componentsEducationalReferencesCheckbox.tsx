// components/EducationalReferencesCheckbox.tsx

'use client';

import React from 'react';

interface EducationalReferencesCheckboxProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
}

export function EducationalReferencesCheckbox({
  checked,
  onChange,
}: EducationalReferencesCheckboxProps) {
  return (
    <label
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '8px',
        fontSize: '14px',
        color: '#374151',
        cursor: 'pointer',
      }}
    >
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        style={{ marginTop: '2px' }}
      />
      <span>
        <strong>Include Educational References</strong>
        <br />
        <span style={{ fontSize: '12px', color: '#6b7280' }}>
          Adds a brief appendix with general IRS resource references (not legal advice).
        </span>
      </span>
    </label>
  );
}

export default EducationalReferencesCheckbox;