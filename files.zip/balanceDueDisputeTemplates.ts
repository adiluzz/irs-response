// lib/letters/balanceDueDisputeTemplates.ts

export interface BalanceDueDisputeVars {
  TODAY_DATE: string;
  TAX_YEAR: string;
  BALANCE: string;
  NOTICE_DATE?: string;
  NOTICE_NUMBER?: string;
  REASON_ID?: string;
  USER_NOTE?: string;
  includeEducationalReferences?: boolean;
}

const OPENINGS = [
  `Dear Internal Revenue Service,`,
  `To Whom It May Concern:`,
  `Dear Sir or Madam:`,
  `Attn: Account Services,`,
  `Dear IRS Account Services:`,
  `To the Internal Revenue Service:`,
  `Dear Taxpayer Services:`,
  `Attn: IRS Account Review,`,
];

const ACKNOWLEDGMENTS = [
  (v: BalanceDueDisputeVars) =>
    `I am writing in response to the notice regarding my ${v.TAX_YEAR} federal tax account, which indicates a balance of ${v.BALANCE}.`,
  (v: BalanceDueDisputeVars) =>
    `This correspondence is in reference to the balance due notice for tax year ${v.TAX_YEAR}. The notice reflects an amount of ${v.BALANCE}.`,
  (v: BalanceDueDisputeVars) =>
    `I received your notice concerning an indicated balance of ${v.BALANCE} for the ${v.TAX_YEAR} tax year.`,
  (v: BalanceDueDisputeVars) =>
    `I am responding to the notice regarding my ${v.TAX_YEAR} account, which shows ${v.BALANCE} as the amount due.`,
  (v: BalanceDueDisputeVars) =>
    `This letter concerns the ${v.TAX_YEAR} balance of ${v.BALANCE} as reflected in your recent correspondence.`,
  (v: BalanceDueDisputeVars) =>
    `I acknowledge receipt of the notice showing a balance of ${v.BALANCE} for tax year ${v.TAX_YEAR}.`,
  (v: BalanceDueDisputeVars) =>
    `I have reviewed the notice for my ${v.TAX_YEAR} federal tax account indicating a balance of ${v.BALANCE}.`,
  (v: BalanceDueDisputeVars) =>
    `In response to your correspondence for ${v.TAX_YEAR}, I note the balance indicated is ${v.BALANCE}.`,
];

const DISPUTE_REQUEST = [
  (v: BalanceDueDisputeVars) =>
    `After reviewing my records, I respectfully request a review of this balance. I believe there may be a discrepancy that warrants clarification.`,
  (v: BalanceDueDisputeVars) =>
    `I am requesting reconsideration of the balance shown. Based on my available records, I believe the amount may not accurately reflect my tax liability for ${v.TAX_YEAR}.`,
  (v: BalanceDueDisputeVars) =>
    `I would like to request an account review. The balance indicated does not appear to align with my records, and I am seeking clarification.`,
  (v: BalanceDueDisputeVars) =>
    `I respectfully request that this account be reviewed for accuracy. To the extent there is any discrepancy, I would appreciate the opportunity to resolve it.`,
  (v: BalanceDueDisputeVars) =>
    `Based on my review of available documentation, I believe the balance may require adjustment. I am requesting a formal account review.`,
  (v: BalanceDueDisputeVars) =>
    `I am writing to request clarification and review of the ${v.TAX_YEAR} balance. My records suggest a potential discrepancy.`,
  (v: BalanceDueDisputeVars) =>
    `I respectfully ask that you review my account for ${v.TAX_YEAR}. The balance shown does not match my understanding of my tax situation.`,
  (v: BalanceDueDisputeVars) =>
    `I am requesting consideration for an account adjustment. After reviewing my records, I believe the balance indicated may not be accurate.`,
  (v: BalanceDueDisputeVars) =>
    `Please review this account balance for potential errors or discrepancies. I have concerns about the accuracy of the amount shown.`,
  (v: BalanceDueDisputeVars) =>
    `I would like to bring to your attention a possible discrepancy in my ${v.TAX_YEAR} account balance and request a review.`,
  (v: BalanceDueDisputeVars) =>
    `To resolve this matter accurately, I am requesting that my account be reviewed. The balance indicated may not reflect all relevant information.`,
  (v: BalanceDueDisputeVars) =>
    `I am seeking clarification on the balance due. I request that you review my account records to confirm the accuracy of this amount.`,
];

const COOPERATION = [
  `I am prepared to provide any documentation or information that may assist in resolving this matter.`,
  `I am willing to supply supporting documentation upon request to facilitate the review process.`,
  `Please let me know what records or documentation would be helpful, and I will provide them promptly.`,
  `I am available to provide any additional information needed to complete this review.`,
  `I will cooperate fully and provide any documentation required to resolve this matter.`,
  `Should you require supporting documents, I am prepared to submit them for your review.`,
  `I am ready to furnish any necessary documentation to support the resolution of this inquiry.`,
  `Any documentation needed to assist with this review will be provided upon request.`,
];

const NEXT_STEPS = [
  `Please advise on the process for reviewing this account and any forms or steps I should complete.`,
  `I request written confirmation of receipt of this inquiry and information on the expected review timeline.`,
  `Kindly inform me of the next steps and any documentation required to proceed with this review.`,
  `Please provide guidance on how this matter will be reviewed and what, if anything, is needed from me.`,
  `I would appreciate information on the review process and expected timeframe for resolution.`,
  `Please notify me of any additional action required on my part and the anticipated review timeline.`,
  `I request acknowledgment of this inquiry and instructions for any further steps.`,
  `Please advise how I may follow up on this request and what to expect regarding the review.`,
];

function pick<T>(arr: T[], seed: number): T {
  return arr[seed % arr.length];
}

function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash);
}

export function generateBalanceDueDisputeLetter(
  vars: BalanceDueDisputeVars,
  expandedExplanation?: string
): string {
  const seed = hashCode(`${vars.TAX_YEAR}-${vars.BALANCE}-${vars.TODAY_DATE}`);

  const opening = pick(OPENINGS, seed);
  const acknowledgment = pick(ACKNOWLEDGMENTS, seed + 1)(vars);
  const disputeRequest = pick(DISPUTE_REQUEST, seed + 2)(vars);
  const cooperation = pick(COOPERATION, seed + 3);
  const nextSteps = pick(NEXT_STEPS, seed + 4);

  let explanationParagraph = '';
  if (expandedExplanation && expandedExplanation.trim()) {
    explanationParagraph = `\n\n${expandedExplanation}`;
  }

  let educationalAppendix = '';
  if (vars.includeEducationalReferences) {
    educationalAppendix = `\n\n---\nEducational Reference (Not Legal Advice):\nFor general information on IRS account review procedures and taxpayer correspondence, taxpayers may review IRS.gov resources. This reference is for informational purposes only and does not constitute tax or legal advice.`;
  }

  return `${opening}

${acknowledgment}

${disputeRequest}${explanationParagraph}

${cooperation}

${nextSteps}${educationalAppendix}`;
}